export const navItems = [
  {
    name: "Inicio",
    img: "",
  },
  {
    name: "Productos",
    url: "",
  },
];

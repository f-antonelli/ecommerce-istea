

export function carrito(){
    const array = [];

    const btn = document.querySelectorAll(`#btn-${item.id}`);
    btn.forEach((element)=>{
        element.addEventListener('click',()=>{
            const productoSeleccionado = element => element.id === btn.id;
            
            
            
        })
    })



}

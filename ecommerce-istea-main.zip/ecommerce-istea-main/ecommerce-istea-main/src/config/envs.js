export const API_URL = "https://dummyjson.com";

